/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.autonoma.elements;

/**
 *
 * @author Fabian Hernandez Castaño, Juan Martin Suarez
 */
public interface Dimensionable {
    public int getX();
    public int getY();
    public int getWidth();
    public int getHeight();
}
