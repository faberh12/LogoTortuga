/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.autonoma.elements;

/**
 *
 * @author Fabian Hernandez Castaño, Juan Martin Suarez
 */
public interface Drawable {
    public void redraw();
   
    public void redraw(int x, int y, int width, int height);
}
